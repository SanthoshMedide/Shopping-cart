# Installation
> `npm install --save @types/serve-static`

# Summary
This package contains type definitions for serve-static (https://github.com/expressjs/serve-static).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/serve-static

Additional Details
 * Last updated: Thu, 09 Nov 2017 15:17:54 GMT
 * Dependencies: express-serve-static-core, mime
 * Global values: none

# Credits
These definitions were written by Uros Smolnik <https://github.com/urossmolnik>, Linus Unnebäck <https://github.com/LinusU>.
