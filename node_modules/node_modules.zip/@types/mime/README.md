# Installation
> `npm install --save @types/mime`

# Summary
This package contains type definitions for mime (https://github.com/broofa/node-mime).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mime

Additional Details
 * Last updated: Mon, 18 Sep 2017 14:13:55 GMT
 * Dependencies: none
 * Global values: mime

# Credits
These definitions were written by Jeff Goddard <https://github.com/jedigo>, Daniel Hritzkiv <https://github.com/dhritzkiv>.
