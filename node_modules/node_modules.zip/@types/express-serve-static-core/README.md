# Installation
> `npm install --save @types/express-serve-static-core`

# Summary
This package contains type definitions for Express (http://expressjs.com).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express-serve-static-core

Additional Details
 * Last updated: Wed, 20 Dec 2017 14:50:50 GMT
 * Dependencies: http, node
 * Global values: none

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov>, Michał Lytek <https://github.com/19majkel94>, Kacper Polak <https://github.com/kacepe>, Satana Charuwichitratana <https://github.com/micksatana>.
