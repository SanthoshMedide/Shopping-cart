exports.extraValidators = ['contains', 'equals', 'matches'];
exports.extraSanitizers = [
  'blacklist',
  'escape',
  'unescape',
  'normalizeEmail',
  'ltrim',
  'rtrim',
  'trim',
  'stripLow',
  'whitelist'
];